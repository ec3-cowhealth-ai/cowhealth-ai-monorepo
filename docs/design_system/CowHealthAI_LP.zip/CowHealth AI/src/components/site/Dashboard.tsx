import dashImg from "@/assets/dashboard.jpg";
import { SectionHeading } from "./Section";

const features = [
  "Monitoramento em tempo real",
  "Perfis individuais por vaca",
  "Tendências históricas",
  "Pontuações de risco",
  "Alertas inteligentes",
  "Relatórios e exportações",
  "Acesso multiusuário",
  "Autenticação segura",
];

export function Dashboard() {
  return (
    <section id="dashboard" className="relative overflow-hidden bg-background py-28 lg:py-36">
      <div className="mx-auto max-w-7xl px-6 lg:px-10">
        <SectionHeading
          eyebrow="A plataforma"
          title={
            <>
              Um painel
              <br />
              <span className="italic text-forest">para todo o rebanho.</span>
            </>
          }
          intro="Projetado para produtores, veterinários e gestores de fazenda — a CowHealth AI transforma dados brutos de sensores em decisões claras e priorizadas."
        />

        <div className="mt-14 overflow-hidden rounded-3xl border border-border bg-card p-2 shadow-elegant sm:p-3">
          <div className="overflow-hidden rounded-2xl">
            <img
              src={dashImg}
              alt="Painel da CowHealth AI"
              width={1920}
              height={1200}
              loading="lazy"
              className="w-full"
            />
          </div>
        </div>

        <div className="mt-12 grid grid-cols-2 gap-3 sm:grid-cols-4">
          {features.map((f) => (
            <div
              key={f}
              className="rounded-xl border border-border bg-card px-4 py-4 text-sm transition-colors hover:border-forest/40"
            >
              <div className="mb-2 h-1 w-6 rounded-full bg-forest/40" />
              {f}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
