import { useEffect, useState } from "react";

const links = [
  { href: "#product", label: "Produto" },
  { href: "#technology", label: "Tecnologia" },
  { href: "#dashboard", label: "Painel" },
  { href: "#welfare", label: "Bem-estar" },
  { href: "#pilot", label: "Piloto" },
];

export function Nav() {
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-500 ${
        scrolled
          ? "bg-background/85 backdrop-blur-xl border-b border-border/60"
          : "bg-transparent"
      }`}
    >
      <nav className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4 lg:px-10">
        <a href="#top" className="flex items-center gap-2.5 group">
          <span className="grid h-8 w-8 place-items-center rounded-md bg-gradient-forest text-primary-foreground">
            <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M4 12c0-4 3-7 8-7s8 3 8 7-3 7-8 7c-1.5 0-2.5-.3-3.5-.8L4 20l1.2-4.2C4.4 14.8 4 13.5 4 12z" />
              <circle cx="10" cy="12" r="1" fill="currentColor" />
              <circle cx="14" cy="12" r="1" fill="currentColor" />
            </svg>
          </span>
          <span className="text-[15px] font-medium tracking-tight">
            CowHealth<span className="text-muted-foreground"> AI</span>
          </span>
        </a>
        <ul className="hidden items-center gap-9 md:flex">
          {links.map((l) => (
            <li key={l.href}>
              <a
                href={l.href}
                className={`text-sm transition-colors ${
                  scrolled ? "text-foreground/75 hover:text-foreground" : "text-cream/85 hover:text-cream"
                }`}
              >
                {l.label}
              </a>
            </li>
          ))}
        </ul>
        <a
          href="/dashboard"
          className="inline-flex items-center gap-1.5 rounded-full bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-all hover:opacity-90"
        >
          Acessar Conta
          <svg viewBox="0 0 24 24" className="h-3.5 w-3.5" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M5 12h14m-5-5 5 5-5 5" />
          </svg>
        </a>
      </nav>
    </header>
  );
}
