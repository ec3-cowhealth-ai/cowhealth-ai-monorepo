import { createFileRoute, Link } from "@tanstack/react-router";
import { useId } from "react";
import cowImage from "@/assets/hero-cow.jpg";

export const Route = createFileRoute("/dashboard")({
  component: DashboardPage,
  head: () => ({
    meta: [
      { title: "Painel — CowHealth AI" },
      { name: "description", content: "Painel CowHealth AI: visão geral do rebanho, alertas e indicadores de saúde em tempo real." },
      { httpEquiv: "content-language", content: "pt-BR" },
    ],
  }),
});

/* ---------------- dados ---------------- */

type Severity = "Alto" | "Médio" | "Baixo";

const kpis: {
  label: string;
  value: string;
  unit?: string;
  sub: string;
  delta: string;
  trend: "up" | "down";
  tone: "good" | "warn";
  icon: "shield" | "heart" | "cow" | "circle" | "temp";
}[] = [
  { label: "Saúde do rebanho", value: "84", unit: "/100", sub: "", delta: "↑ 6 nos últimos 7 dias", trend: "up", tone: "good", icon: "shield" },
  { label: "Vacas em risco", value: "18", sub: "7,3% do rebanho", delta: "↑ 3 nos últimos 7 dias", trend: "up", tone: "warn", icon: "heart" },
  { label: "Vacas recém-paridas", value: "24", sub: "9,7% do rebanho", delta: "↓ 2 nos últimos 7 dias", trend: "down", tone: "good", icon: "cow" },
  { label: "Vacas em aberto", value: "32", sub: "13,0% do rebanho", delta: "↑ 1 nos últimos 7 dias", trend: "up", tone: "good", icon: "circle" },
  { label: "Temp. média", value: "101,2", unit: "°F", sub: "", delta: "↑ 0,4°F nos últimos 7 dias", trend: "up", tone: "warn", icon: "temp" },
];

const alertFeed: { id: string; title: string; cow: string; time: string; sev: Severity; icon: "temp" | "heart" | "activity" | "clock" }[] = [
  { id: "1", title: "Temperatura elevada", cow: "Vaca 0892", time: "há 10 min", sev: "Alto", icon: "temp" },
  { id: "2", title: "Frequência cardíaca elevada", cow: "Vaca 1247", time: "há 25 min", sev: "Médio", icon: "heart" },
  { id: "3", title: "Atividade baixa", cow: "Vaca 0671", time: "há 1 h", sev: "Médio", icon: "activity" },
  { id: "4", title: "Temperatura elevada", cow: "Vaca 2115", time: "há 2 h", sev: "Alto", icon: "temp" },
  { id: "5", title: "Frequência cardíaca elevada", cow: "Vaca 0456", time: "há 3 h", sev: "Médio", icon: "heart" },
  { id: "6", title: "Tratamento agendado", cow: "Vaca 0788", time: "há 4 h", sev: "Baixo", icon: "clock" },
];

const timeline = [
  { time: "00:15", label: "Ruminação", sub: "45 min", icon: "heart" },
  { time: "06:20", label: "Alimentação", sub: "32 min", icon: "cow" },
  { time: "11:05", label: "Atividade baixa", sub: "25 min", icon: "alert" },
  { time: "15:10", label: "Alimentação", sub: "28 min", icon: "cow" },
  { time: "19:45", label: "Ruminação", sub: "42 min", icon: "heart" },
];

const navItems = [
  { label: "Visão geral", icon: "grid", active: true },
  { label: "Rebanho", icon: "cow" },
  { label: "Alertas", icon: "bell", badge: 6 },
  { label: "Saúde", icon: "heart" },
  { label: "Relatórios", icon: "report" },
  { label: "Tratamentos", icon: "drop" },
  { label: "Reprodução", icon: "spark" },
  { label: "Inventário", icon: "box" },
  { label: "Configurações", icon: "gear" },
];

/* ---------------- componente ---------------- */

function DashboardPage() {
  return (
    <div className="min-h-screen bg-[#f5f1ea] text-[#1a1f1c] font-sans">
      <div className="flex">
        <Sidebar />
        <main className="flex-1 min-w-0 p-8 space-y-6">
          <TopBar />
          <KpiRow />
          <div className="grid grid-cols-12 gap-6">
            <CowProfile />
            <CenterPanel />
            <AlertFeed />
          </div>
          <ActivityTimeline />
        </main>
      </div>
    </div>
  );
}

/* ---------------- sidebar ---------------- */

function Sidebar() {
  return (
    <aside className="w-64 shrink-0 min-h-screen bg-[#0f2e1f] text-[#d9e4dc] p-5 flex flex-col">
      <Link to="/" className="flex items-center gap-3 mb-8 px-2">
        <div className="w-10 h-10 rounded-xl bg-[#1a4632] flex items-center justify-center">
          <CowGlyph className="w-6 h-6 text-[#9bd3a8]" />
        </div>
        <div>
          <div className="font-semibold text-white tracking-tight">CowHealth AI</div>
          <div className="text-xs text-[#7fa890]">Saúde do rebanho</div>
        </div>
      </Link>

      <nav className="flex-1 space-y-1">
        {navItems.map((n) => (
          <button
            key={n.label}
            className={[
              "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-colors",
              n.active ? "bg-[#1a4632] text-white" : "text-[#a8c1b1] hover:bg-[#163d2a] hover:text-white",
            ].join(" ")}
          >
            <NavIcon name={n.icon} />
            <span className="flex-1 text-left">{n.label}</span>
            {n.badge && (
              <span className="text-[10px] font-semibold bg-[#d7553a] text-white rounded-full px-2 py-0.5">
                {n.badge}
              </span>
            )}
          </button>
        ))}
      </nav>

      <div className="mt-6 rounded-xl bg-[#163d2a] p-4 text-sm">
        <div className="flex items-center gap-2 text-[#a8c1b1]">
          <SpeechIcon className="w-4 h-4" />
          Precisa de ajuda?
        </div>
      </div>

      <div className="mt-4 flex items-center gap-3 px-2">
        <div className="w-10 h-10 rounded-full bg-[#1a4632] flex items-center justify-center text-white font-semibold">
          JH
        </div>
        <div className="min-w-0">
          <div className="text-sm text-white truncate">Dr. James Harper</div>
          <div className="text-xs text-[#7fa890] truncate">Fazenda Vale Verde</div>
        </div>
        <ChevronDown className="w-4 h-4 text-[#7fa890]" />
      </div>
    </aside>
  );
}

/* ---------------- top bar ---------------- */

function TopBar() {
  return (
    <header className="flex items-end justify-between gap-4 flex-wrap">
      <div>
        <h1 className="font-display text-4xl md:text-5xl tracking-tight text-[#1a1f1c]">
          Visão geral do rebanho
        </h1>
        <div className="mt-1 text-sm text-[#5e6b62]">
          Fazenda Vale Verde · 247 cabeças
        </div>
      </div>
      <div className="flex items-center gap-3">
        <button className="flex items-center gap-2 bg-white border border-[#e3ddd1] rounded-xl px-4 py-2.5 text-sm shadow-sm">
          <CalIcon className="w-4 h-4 text-[#1a4632]" />
          20 mai – 26 mai, 2024
          <ChevronDown className="w-4 h-4 text-[#5e6b62]" />
        </button>
        <button className="flex items-center gap-2 bg-white border border-[#e3ddd1] rounded-xl px-4 py-2.5 text-sm shadow-sm">
          <FilterIcon className="w-4 h-4 text-[#1a4632]" />
          Filtrar
        </button>
      </div>
    </header>
  );
}

/* ---------------- KPI ---------------- */

function KpiRow() {
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-5 gap-4">
      {kpis.map((k, i) => (
        <KpiCard key={i} {...k} index={i} />
      ))}
    </div>
  );
}

function KpiCard({ label, value, unit, sub, delta, trend, tone, icon, index }: typeof kpis[number] & { index: number }) {
  const goodColor = "#1f7a4a";
  const warnColor = "#d97a2c";
  const accent = tone === "good" ? goodColor : warnColor;
  return (
    <article className="bg-white rounded-2xl p-5 border border-[#ece6d8] shadow-[0_1px_2px_rgba(0,0,0,0.03)]">
      <div className="flex items-start gap-3">
        <div
          className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0"
          style={{ background: tone === "good" ? "#e6f1ea" : "#fbe9d8" }}
        >
          <KpiIcon name={icon} color={accent} />
        </div>
        <div className="min-w-0">
          <div className="text-xs text-[#5e6b62]">{label}</div>
          <div className="flex items-baseline gap-1 mt-1">
            <span className="text-2xl font-semibold text-[#1a1f1c]">{value}</span>
            {unit && <span className="text-xs text-[#5e6b62]">{unit}</span>}
          </div>
          {sub && <div className="text-[11px] text-[#5e6b62] -mt-0.5">{sub}</div>}
        </div>
      </div>
      <div className="mt-3 text-[11px]" style={{ color: accent }}>{delta}</div>
      <div className="mt-2 h-8">
        <Sparkline color={accent} variant={index % 2 === 0 ? "a" : "b"} />
      </div>
    </article>
  );
}

/* ---------------- cow profile ---------------- */

function CowProfile() {
  const rows = [
    ["Lote / Grupo", "Lactação 1"],
    ["Dias em lactação", "143"],
    ["Status reprodutivo", "Em aberto"],
    ["Último parto", "28 jan, 2024"],
    ["Touro", "Delta-Lambda"],
    ["Brinco", "1247"],
  ];
  return (
    <section className="col-span-12 lg:col-span-3 bg-white rounded-2xl border border-[#ece6d8] p-5 shadow-[0_1px_2px_rgba(0,0,0,0.03)]">
      <div className="relative w-44 h-44 mx-auto rounded-full overflow-hidden border-4 border-[#f5f1ea] shadow">
        <img src={cowImage} alt="Vaca 1247" className="w-full h-full object-cover" />
        <button className="absolute bottom-1 right-1 w-8 h-8 rounded-full bg-white border border-[#ece6d8] flex items-center justify-center shadow">
          <CameraIcon className="w-4 h-4 text-[#1a4632]" />
        </button>
      </div>
      <div className="text-center mt-4">
        <div className="font-display text-3xl text-[#1a1f1c]">Vaca 1247</div>
        <div className="text-xs text-[#5e6b62] mt-1 tracking-wide">HOLANDESA · 5,2 ANOS · LACT 3</div>
      </div>
      <dl className="mt-5 space-y-3 text-sm">
        {rows.map(([k, v]) => (
          <div key={k} className="flex items-center justify-between">
            <dt className="text-[#5e6b62] flex items-center gap-2">
              <BulletIcon /> {k}
            </dt>
            <dd className="text-[#1a1f1c] font-medium">{v}</dd>
          </div>
        ))}
      </dl>
      <button className="mt-5 w-full flex items-center justify-between px-4 py-2.5 rounded-xl border border-[#ece6d8] text-sm hover:bg-[#faf7f0]">
        Ver perfil completo
        <ChevronRight className="w-4 h-4" />
      </button>
    </section>
  );
}

/* ---------------- center panel ---------------- */

function CenterPanel() {
  return (
    <section className="col-span-12 lg:col-span-6 space-y-4">
      <div className="bg-white rounded-2xl border border-[#ece6d8] p-5 shadow-[0_1px_2px_rgba(0,0,0,0.03)]">
        <div className="flex items-center gap-6 border-b border-[#ece6d8] -mx-5 px-5 pb-3 text-sm">
          {["Saúde", "Atividade", "Reprodução", "Tratamentos", "Notas"].map((t, i) => (
            <button
              key={t}
              className={[
                "pb-2 -mb-px",
                i === 0 ? "text-[#1f7a4a] font-semibold border-b-2 border-[#1f7a4a]" : "text-[#5e6b62]",
              ].join(" ")}
            >
              {t}
            </button>
          ))}
        </div>

        <div className="pt-4">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-2">
              <TempIcon className="w-5 h-5 text-[#1f7a4a]" />
              <div className="font-medium">Temperatura corporal</div>
              <span className="text-xs text-[#5e6b62]">°F</span>
            </div>
            <div className="flex items-center gap-4">
              <div className="text-right">
                <div className="text-xl font-semibold text-[#d97a2c]">101,8 <span className="text-xs">°F</span></div>
                <div className="text-[11px] text-[#1f7a4a]">↑ 0,9°F vs. ontem</div>
              </div>
              <button className="text-xs px-3 py-1.5 rounded-lg border border-[#ece6d8] flex items-center gap-1">
                7 dias <ChevronDown className="w-3 h-3" />
              </button>
            </div>
          </div>
          <TempChart />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="bg-white rounded-2xl border border-[#ece6d8] p-5 shadow-[0_1px_2px_rgba(0,0,0,0.03)]">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-2">
              <HeartIcon className="w-5 h-5 text-[#1f7a4a]" />
              <div className="font-medium">Freq. cardíaca</div>
            </div>
            <div className="text-right">
              <div><span className="text-xl font-semibold">72</span> <span className="text-xs text-[#5e6b62]">bpm</span></div>
              <div className="text-[11px] text-[#1f7a4a]">Normal</div>
            </div>
          </div>
          <div className="flex justify-end mt-1">
            <button className="text-xs px-3 py-1 rounded-lg border border-[#ece6d8] flex items-center gap-1">
              7 dias <ChevronDown className="w-3 h-3" />
            </button>
          </div>
          <HeartChart />
        </div>

        <div className="bg-white rounded-2xl border border-[#ece6d8] p-5 shadow-[0_1px_2px_rgba(0,0,0,0.03)]">
          <div className="flex items-center gap-2 mb-3">
            <ShieldIcon className="w-5 h-5 text-[#1f7a4a]" />
            <div className="font-medium">Score de risco</div>
          </div>
          <div className="flex items-center gap-4">
            <RiskGauge value={28} />
            <ul className="text-xs space-y-2 flex-1">
              <li className="flex items-center justify-between"><span className="flex items-center gap-1.5"><CheckDot/> Temperatura</span><span className="text-[#1f7a4a]">Normal</span></li>
              <li className="flex items-center justify-between"><span className="flex items-center gap-1.5"><CheckDot/> Freq. cardíaca</span><span className="text-[#1f7a4a]">Normal</span></li>
              <li className="flex items-center justify-between"><span className="flex items-center gap-1.5"><CheckDot tone="warn"/> Atividade</span><span className="text-[#d97a2c]">Levemente baixa</span></li>
              <li className="flex items-center justify-between"><span className="flex items-center gap-1.5"><CheckDot/> Ruminação</span><span className="text-[#1f7a4a]">Normal</span></li>
            </ul>
          </div>
          <div className="text-[11px] text-[#5e6b62] mt-3">Fatores contribuintes</div>
        </div>
      </div>
    </section>
  );
}

/* ---------------- alert feed ---------------- */

function AlertFeed() {
  return (
    <aside className="col-span-12 lg:col-span-3 space-y-4">
      <div className="bg-white rounded-2xl border border-[#ece6d8] p-5 shadow-[0_1px_2px_rgba(0,0,0,0.03)]">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <span className="font-medium">Feed de alertas</span>
            <span className="text-[10px] bg-[#d7553a] text-white rounded-full w-5 h-5 flex items-center justify-center font-semibold">6</span>
          </div>
          <button className="text-xs text-[#1f7a4a] font-medium">Ver tudo</button>
        </div>
        <ul className="space-y-3">
          {alertFeed.map((a) => (
            <li key={a.id} className="flex items-start gap-3">
              <div
                className="w-9 h-9 rounded-xl flex items-center justify-center shrink-0"
                style={{ background: a.sev === "Alto" ? "#fde7df" : a.sev === "Médio" ? "#fbe9d8" : "#e6f1ea" }}
              >
                <AlertIcon name={a.icon} color={a.sev === "Alto" ? "#d7553a" : a.sev === "Médio" ? "#d97a2c" : "#1f7a4a"} />
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-medium text-[#1a1f1c] truncate">{a.title}</div>
                <div className="text-xs text-[#5e6b62]">{a.cow}</div>
                <div className="text-[11px] text-[#8a948c] mt-0.5">{a.time}</div>
              </div>
              <SevBadge sev={a.sev} />
            </li>
          ))}
        </ul>
      </div>

      <div className="rounded-2xl bg-[#0f2e1f] text-white p-5 relative overflow-hidden">
        <div className="text-base font-semibold">Monitore em qualquer lugar</div>
        <p className="text-xs text-[#a8c1b1] mt-1">Receba alertas em tempo real e atualizações do rebanho no celular.</p>
        <button className="mt-3 inline-flex items-center gap-1.5 bg-white text-[#0f2e1f] text-xs font-semibold px-3 py-1.5 rounded-lg">
          Saiba mais <ArrowUpRight className="w-3 h-3" />
        </button>
        <div className="absolute -right-3 -bottom-3 w-24 h-32 rounded-2xl bg-[#163d2a] border-4 border-[#0f2e1f] rotate-6" />
      </div>
    </aside>
  );
}

/* ---------------- activity timeline ---------------- */

function ActivityTimeline() {
  return (
    <section className="bg-white rounded-2xl border border-[#ece6d8] p-5 shadow-[0_1px_2px_rgba(0,0,0,0.03)]">
      <div className="flex items-center justify-between">
        <div className="font-medium">Linha do tempo de atividade</div>
        <button className="text-xs px-3 py-1.5 rounded-lg border border-[#ece6d8] flex items-center gap-1">
          Hoje <ChevronDown className="w-3 h-3" />
        </button>
      </div>
      <div className="relative mt-6">
        <div className="h-px bg-[#ece6d8]" />
        <div className="grid grid-cols-6 text-[11px] text-[#5e6b62] mt-2">
          {["00h", "04h", "08h", "12h", "16h", "20h"].map((h) => <div key={h}>{h}</div>)}
        </div>
        <div className="grid grid-cols-5 gap-4 mt-6">
          {timeline.map((t, i) => (
            <div key={i} className="flex items-start gap-3">
              <div className="w-9 h-9 rounded-xl bg-[#e6f1ea] flex items-center justify-center shrink-0">
                <TimelineIcon name={t.icon} />
              </div>
              <div>
                <div className="text-xs text-[#5e6b62]">{t.time}</div>
                <div className="text-sm font-medium">{t.label}</div>
                <div className="text-[11px] text-[#5e6b62]">{t.sub}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------------- charts ---------------- */

function Sparkline({ color, variant }: { color: string; variant: "a" | "b" }) {
  const a = "M0,18 L10,15 L20,20 L30,14 L40,16 L50,10 L60,12 L70,8 L80,11 L90,7 L100,9";
  const b = "M0,10 L10,14 L20,11 L30,16 L40,13 L50,17 L60,14 L70,18 L80,15 L90,19 L100,17";
  const d = variant === "a" ? a : b;
  return (
    <svg viewBox="0 0 100 24" preserveAspectRatio="none" className="w-full h-full">
      <path d={d} fill="none" stroke={color} strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function TempChart() {
  const gradId = useId();
  // Generate a wavy line
  const points = Array.from({ length: 40 }, (_, i) => {
    const x = (i / 39) * 100;
    const base = 50;
    const y = base - Math.sin(i * 0.45) * 8 - Math.cos(i * 0.9) * 3 + (i > 32 ? -6 : 0);
    return [x, y];
  });
  const path = points.map((p, i) => `${i === 0 ? "M" : "L"}${p[0]},${p[1]}`).join(" ");
  const area = `${path} L100,90 L0,90 Z`;
  const days = ["20 mai", "21 mai", "22 mai", "23 mai", "24 mai", "25 mai", "26 mai"];
  return (
    <div className="mt-3">
      <div className="relative h-44">
        <svg viewBox="0 0 100 90" preserveAspectRatio="none" className="absolute inset-0 w-full h-full">
          <defs>
            <linearGradient id={gradId} x1="0" x2="0" y1="0" y2="1">
              <stop offset="0%" stopColor="#1f7a4a" stopOpacity="0.25" />
              <stop offset="100%" stopColor="#1f7a4a" stopOpacity="0" />
            </linearGradient>
          </defs>
          <line x1="0" y1="22" x2="100" y2="22" stroke="#d7553a" strokeWidth="0.4" strokeDasharray="2 2" />
          <line x1="0" y1="78" x2="100" y2="78" stroke="#3b6fa0" strokeWidth="0.4" strokeDasharray="2 2" />
          <path d={area} fill={`url(#${gradId})`} />
          <path d={path} fill="none" stroke="#1f7a4a" strokeWidth="0.9" strokeLinecap="round" />
          <circle cx={points[points.length - 1][0]} cy={points[points.length - 1][1]} r="1.6" fill="#1f7a4a" />
        </svg>
        <div className="absolute -top-1 right-0 text-[10px] text-[#d7553a]">104,0 Limite de febre</div>
        <div className="absolute bottom-3 right-0 text-[10px] text-[#3b6fa0]">99,0 Limite mínimo</div>
        <div className="absolute left-0 top-0 h-full flex flex-col justify-between text-[10px] text-[#5e6b62] pr-2">
          <span>104,0</span><span>102,0</span><span>100,0</span><span>98,0</span>
        </div>
      </div>
      <div className="grid grid-cols-7 text-[10px] text-[#5e6b62] mt-1">
        {days.map((d) => <div key={d}>{d}</div>)}
      </div>
    </div>
  );
}

function HeartChart() {
  const points = Array.from({ length: 30 }, (_, i) => {
    const x = (i / 29) * 100;
    const y = 30 - Math.sin(i * 0.6) * 8 - Math.cos(i * 1.2) * 4;
    return `${i === 0 ? "M" : "L"}${x},${y}`;
  }).join(" ");
  return (
    <div className="mt-2 h-24 relative">
      <svg viewBox="0 0 100 50" preserveAspectRatio="none" className="w-full h-full">
        <path d={points} fill="none" stroke="#1f7a4a" strokeWidth="1" strokeLinecap="round" />
      </svg>
      <div className="absolute left-0 top-0 text-[10px] text-[#5e6b62]">100</div>
      <div className="absolute left-0 bottom-4 text-[10px] text-[#5e6b62]">40</div>
      <div className="flex justify-between text-[10px] text-[#5e6b62]">
        <span>20 mai</span><span>26 mai</span>
      </div>
    </div>
  );
}

function RiskGauge({ value }: { value: number }) {
  const r = 32;
  const c = 2 * Math.PI * r;
  const offset = c - (value / 100) * c;
  return (
    <div className="relative w-24 h-24 shrink-0">
      <svg viewBox="0 0 80 80" className="w-full h-full -rotate-90">
        <circle cx="40" cy="40" r={r} stroke="#ece6d8" strokeWidth="7" fill="none" />
        <circle
          cx="40" cy="40" r={r}
          stroke="#1f7a4a" strokeWidth="7" fill="none" strokeLinecap="round"
          strokeDasharray={c} strokeDashoffset={offset}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <div className="text-2xl font-semibold">{value}</div>
        <div className="text-[10px] text-[#5e6b62] -mt-0.5">/100</div>
      </div>
      <div className="text-center text-[11px] text-[#1f7a4a] font-medium mt-1">Risco baixo</div>
    </div>
  );
}

/* ---------------- pequenos componentes ---------------- */

function SevBadge({ sev }: { sev: Severity }) {
  const map: Record<Severity, string> = {
    Alto: "bg-[#fde7df] text-[#d7553a]",
    Médio: "bg-[#fbe9d8] text-[#d97a2c]",
    Baixo: "bg-[#e6f1ea] text-[#1f7a4a]",
  };
  return <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${map[sev]}`}>{sev}</span>;
}

function CheckDot({ tone = "good" }: { tone?: "good" | "warn" }) {
  const c = tone === "good" ? "#1f7a4a" : "#d97a2c";
  return (
    <span className="w-3.5 h-3.5 rounded-full flex items-center justify-center" style={{ background: tone === "good" ? "#e6f1ea" : "#fbe9d8" }}>
      <svg viewBox="0 0 10 10" className="w-2 h-2"><path d="M2 5 L4 7 L8 3" stroke={c} strokeWidth="1.5" fill="none" strokeLinecap="round" strokeLinejoin="round"/></svg>
    </span>
  );
}

function BulletIcon() {
  return <span className="w-3.5 h-3.5 rounded-full bg-[#e6f1ea] inline-block" />;
}

/* ---------------- ícones ---------------- */

function NavIcon({ name }: { name: string }) {
  const s = "w-4 h-4";
  switch (name) {
    case "grid": return <svg className={s} viewBox="0 0 20 20" fill="currentColor"><path d="M3 3h6v6H3zM11 3h6v6h-6zM3 11h6v6H3zM11 11h6v6h-6z"/></svg>;
    case "cow": return <CowGlyph className={s} />;
    case "bell": return <svg className={s} viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.6"><path d="M5 9a5 5 0 0110 0v3l1 2H4l1-2V9zM8 16a2 2 0 004 0"/></svg>;
    case "heart": return <svg className={s} viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.6"><path d="M10 16s-6-3.5-6-8a3.5 3.5 0 016-2.5A3.5 3.5 0 0116 8c0 4.5-6 8-6 8z"/></svg>;
    case "report": return <svg className={s} viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.6"><rect x="4" y="3" width="12" height="14" rx="1.5"/><path d="M7 7h6M7 10h6M7 13h4"/></svg>;
    case "drop": return <svg className={s} viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.6"><path d="M10 3c2 4 5 6 5 9a5 5 0 01-10 0c0-3 3-5 5-9z"/></svg>;
    case "spark": return <svg className={s} viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.6"><path d="M10 3v4M10 13v4M3 10h4M13 10h4"/></svg>;
    case "box": return <svg className={s} viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.6"><path d="M3 7l7-4 7 4v6l-7 4-7-4V7zM3 7l7 4 7-4M10 11v8"/></svg>;
    case "gear": return <svg className={s} viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.6"><circle cx="10" cy="10" r="2.5"/><path d="M10 2v2M10 16v2M2 10h2M16 10h2M4.5 4.5l1.5 1.5M14 14l1.5 1.5M15.5 4.5L14 6M6 14l-1.5 1.5"/></svg>;
    default: return null;
  }
}

function KpiIcon({ name, color }: { name: string; color: string }) {
  const props = { className: "w-5 h-5", style: { color }, fill: "none", stroke: "currentColor", strokeWidth: 1.6 };
  switch (name) {
    case "shield": return <svg {...props} viewBox="0 0 20 20"><path d="M10 2l6 2v5c0 4-3 7-6 9-3-2-6-5-6-9V4l6-2z"/><path d="M7 10l2 2 4-4"/></svg>;
    case "heart": return <svg {...props} viewBox="0 0 20 20"><path d="M10 16s-6-3.5-6-8a3.5 3.5 0 016-2.5A3.5 3.5 0 0116 8c0 4.5-6 8-6 8z"/></svg>;
    case "cow": return <CowGlyph className="w-5 h-5" style={{ color }} />;
    case "circle": return <svg {...props} viewBox="0 0 20 20"><circle cx="10" cy="10" r="6"/><path d="M10 4v3M10 13v3M4 10h3M13 10h3"/></svg>;
    case "temp": return <svg {...props} viewBox="0 0 20 20"><path d="M10 3a2 2 0 012 2v7a3 3 0 11-4 0V5a2 2 0 012-2z"/></svg>;
    default: return null;
  }
}

function AlertIcon({ name, color }: { name: string; color: string }) {
  const p = { className: "w-4 h-4", style: { color }, fill: "none", stroke: "currentColor", strokeWidth: 1.6 };
  switch (name) {
    case "temp": return <svg {...p} viewBox="0 0 20 20"><path d="M10 3a2 2 0 012 2v7a3 3 0 11-4 0V5a2 2 0 012-2z"/></svg>;
    case "heart": return <svg {...p} viewBox="0 0 20 20"><path d="M10 16s-6-3.5-6-8a3.5 3.5 0 016-2.5A3.5 3.5 0 0116 8c0 4.5-6 8-6 8z"/></svg>;
    case "activity": return <svg {...p} viewBox="0 0 20 20"><path d="M3 10h3l2-5 4 10 2-5h3"/></svg>;
    case "clock": return <svg {...p} viewBox="0 0 20 20"><circle cx="10" cy="10" r="6"/><path d="M10 7v3l2 1"/></svg>;
    default: return null;
  }
}

function TimelineIcon({ name }: { name: string }) {
  const p = { className: "w-4 h-4 text-[#1f7a4a]", fill: "none", stroke: "currentColor", strokeWidth: 1.6 };
  switch (name) {
    case "heart": return <svg {...p} viewBox="0 0 20 20"><path d="M10 16s-6-3.5-6-8a3.5 3.5 0 016-2.5A3.5 3.5 0 0116 8c0 4.5-6 8-6 8z"/></svg>;
    case "cow": return <CowGlyph className="w-4 h-4 text-[#1f7a4a]" />;
    case "alert": return <svg {...p} viewBox="0 0 20 20"><path d="M10 3l8 14H2L10 3z"/><path d="M10 9v3M10 14v.5"/></svg>;
    default: return null;
  }
}

function CowGlyph({ className, style }: { className?: string; style?: React.CSSProperties }) {
  return (
    <svg className={className} style={style} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M5 11c0-3 2-5 7-5s7 2 7 5c0 1-.5 2-1 2.5V17a2 2 0 01-2 2h-1v-2H9v2H8a2 2 0 01-2-2v-3.5c-.5-.5-1-1.5-1-2.5z"/>
      <path d="M9 14h.01M15 14h.01M4 9l-2-1M20 9l2-1"/>
    </svg>
  );
}

function ChevronDown({ className = "w-4 h-4" }) { return <svg className={className} viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.6"><path d="M5 8l5 5 5-5"/></svg>; }
function ChevronRight({ className = "w-4 h-4" }) { return <svg className={className} viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.6"><path d="M8 5l5 5-5 5"/></svg>; }
function CalIcon({ className = "w-4 h-4" }) { return <svg className={className} viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.6"><rect x="3" y="5" width="14" height="12" rx="1.5"/><path d="M3 8h14M7 3v4M13 3v4"/></svg>; }
function FilterIcon({ className = "w-4 h-4" }) { return <svg className={className} viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.6"><path d="M3 5h14M5 10h10M8 15h4"/></svg>; }
function CameraIcon({ className = "w-4 h-4" }) { return <svg className={className} viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.6"><rect x="3" y="6" width="14" height="10" rx="2"/><circle cx="10" cy="11" r="2.5"/><path d="M7 6l1-2h4l1 2"/></svg>; }
function SpeechIcon({ className = "w-4 h-4" }) { return <svg className={className} viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.6"><path d="M4 5h12v8H9l-3 3v-3H4z"/></svg>; }
function TempIcon({ className = "w-5 h-5" }) { return <svg className={className} viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.6"><path d="M10 3a2 2 0 012 2v7a3 3 0 11-4 0V5a2 2 0 012-2z"/></svg>; }
function HeartIcon({ className = "w-5 h-5" }) { return <svg className={className} viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.6"><path d="M10 16s-6-3.5-6-8a3.5 3.5 0 016-2.5A3.5 3.5 0 0116 8c0 4.5-6 8-6 8z"/></svg>; }
function ShieldIcon({ className = "w-5 h-5" }) { return <svg className={className} viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.6"><path d="M10 2l6 2v5c0 4-3 7-6 9-3-2-6-5-6-9V4l6-2z"/></svg>; }
function ArrowUpRight({ className = "w-3 h-3" }) { return <svg className={className} viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.8"><path d="M6 14L14 6M8 6h6v6"/></svg>; }
