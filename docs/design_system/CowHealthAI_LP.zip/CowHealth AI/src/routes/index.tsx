import { createFileRoute } from "@tanstack/react-router";
import { Nav } from "@/components/site/Nav";
import { Hero } from "@/components/site/Hero";
import { Problem } from "@/components/site/Problem";
import { Solution } from "@/components/site/Solution";
import { Collar } from "@/components/site/Collar";
import { Intelligence } from "@/components/site/Intelligence";
import { Dashboard } from "@/components/site/Dashboard";
import { Value } from "@/components/site/Value";
import { Trust } from "@/components/site/Trust";
import { Pilot } from "@/components/site/Pilot";
import { Footer } from "@/components/site/Footer";

export const Route = createFileRoute("/")({
  component: Index,
  head: () => ({
    meta: [
      { title: "CowHealth AI — Inteligência preditiva de saúde para rebanhos leiteiros" },
      {
        name: "description",
        content:
          "A CowHealth AI transforma dados fisiológicos e comportamentais em tempo real em alertas precoces de risco para fazendas leiteiras. Coleira inteligente, IA transparente, clareza veterinária.",
      },
      { property: "og:title", content: "CowHealth AI — Inteligência preditiva de saúde para rebanhos leiteiros" },
      { property: "og:description", content: "Visibilidade contínua do rebanho. Alertas de risco transparentes. Foco no bem-estar animal." },
      { property: "og:type", content: "website" },
      { httpEquiv: "content-language", content: "pt-BR" },
    ],
  }),
});

function Index() {
  return (
    <main className="bg-background text-foreground">
      <Nav />
      <Hero />
      <Problem />
      <Solution />
      <Collar />
      <Intelligence />
      <Dashboard />
      <Value />
      <Trust />
      <Pilot />
      <Footer />
    </main>
  );
}
